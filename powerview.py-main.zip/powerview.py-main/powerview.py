import powerview

powerview.main()